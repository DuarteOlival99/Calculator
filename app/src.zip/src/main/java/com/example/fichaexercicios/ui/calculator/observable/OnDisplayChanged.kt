package com.example.fichaexercicios.ui.calculator.observable

interface OnDisplayChanged {

    fun onDisplayChanged(value: String?)

}